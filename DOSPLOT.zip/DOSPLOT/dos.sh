#!/bin/bash
# this shell script automates the restarting process 
truncate -s 0 dosplot1.txt
truncate -s 0 dosplot2.txt
truncate -s 0 dosplot3.txt


echo "Please Specify Which Iteration You Would Like to Use For DOS Plotting?"
read ITER
let ITER-=1
echo "Now Specify Number Of Energy Points"
read IE

line1="$(grep -n "STATE" pw7.print.ss1 | cut -d: -f1)"
read -a array1 <<< $line1;

let ls=${array1[$ITER]}+8
let le=${array1[$ITER]}+8+$IE-1
let ld=$le-$ls+1

sed "$ls,$le"'!d' pw7.print.ss1 >> dosplot1.txt
echo "Copied dosplot1 Correctly"


let ls=${array1[$ITER+1]}+8
let le=${array1[$ITER+1]}+8+$IE-1

sed "$ls,$le"'!d' pw7.print.ss1 >> dosplot2.txt
echo "Copied dosplot2 Correctly"


let ls=${array1[$ITER+2]}+8
let le=${array1[$ITER+2]}+8+$IE-1

sed "$ls,$le"'!d' pw7.print.ss1 >> dosplot3.txt
echo "Copied dosplot3 Correctly"

gf95link -a -r8 dosplot
